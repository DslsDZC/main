import getpass
import os
import sqlite3
from mysql.connector import connect, Error
import bcrypt
import logging

# 配置日志记录
logging.basicConfig(filename='app.log', level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# 创建用户的函数
def create_user(cursor, username, password):
    try:
        # 生成密码的bcrypt哈希值
        hashed_password = bcrypt.hashpw(password.encode(), bcrypt.gensalt())
        # 使用预编译语句创建用户
        cursor.execute("CREATE USER %s@'localhost' IDENTIFIED BY %s;", (username, hashed_password.decode()))
        logging.info(f"用户 {username} 创建成功。")
    except Error as e:
        logging.error(f"创建用户失败: {e}")
        raise e

# 授予权限的函数
def grant_privileges(cursor, username):
    try:
        # 使用预编译语句授予权限
        cursor.execute("GRANT ALL PRIVILEGES ON *.* TO %s@'localhost';", (username,))
        logging.info(f"用户 {username} 的权限授予成功。")
    except Error as e:
        logging.error(f"授予权限失败: {e}")
        raise e

# 创建数据库的函数
def create_database(cursor, db_name):
    try:
        # 使用预编译语句创建数据库
        cursor.execute("CREATE DATABASE IF NOT EXISTS %s;", (db_name,))
        logging.info(f"数据库 {db_name} 创建成功。")
    except Error as e:
        logging.error(f"创建数据库失败: {e}")
        raise e

# 验证输入的函数
def validate_input(username, password, db_name):
    if not username or not password or not db_name:
        raise ValueError("用户名、密码和数据库名称不能为空。")
    return True

# 限制用户权限的函数
def restrict_user_permissions(cursor, username):
    try:
        # 使用预编译语句限制用户权限
        cursor.execute("REVOKE ALL PRIVILEGES ON *.* FROM %s@'localhost';", (username,))
        logging.info(f"用户 {username} 的权限已被限制。")
    except Error as e:
        logging.error(f"限制用户权限失败: {e}")
        raise e

# 主函数
def main():
    username = input("请输入一个用户名: ")
    password = getpass.getpass("请输入一个密码: ")
    db_name = input("请输入一个数据库名称: ")

    try:
        if validate_input(username, password, db_name):
            # 连接到SQLite数据库
            conn = sqlite3.connect('user_data.db')
            c = conn.cursor()
            
            # 创建用户表
            c.execute('''CREATE TABLE IF NOT EXISTS users
                         (username TEXT PRIMARY KEY, password TEXT, database TEXT)''')
            
            # 插入用户数据
            c.execute("INSERT INTO users VALUES (?, ?, ?)", (username, password, db_name))
            
            # 提交更改
            conn.commit()
            logging.info(f"用户 {username} 的信息已存储到SQLite数据库。")
            
            # 关闭数据库连接
            conn.close()

            # 连接到MySQL数据库
            connection = connect(
                host='localhost',
                user='root',
                password='your_mysql_password',
                database='mysql',
                ssl_ca='ca.pem',       # 证书文件路径
                ssl_cert='client-cert.pem',  # 客户端证书文件路径
                ssl_key='client-key.pem'     # 客户端密钥文件路径
            )
            cursor = connection.cursor()

            # 创建用户并授予权限
            create_user(cursor, username, password)
            grant_privileges(cursor, username)
            create_database(cursor, db_name)
            restrict_user_permissions(cursor, username)

            # 提交更改并关闭连接
            connection.commit()
            connection.close()

    except Error as e:
        logging.error(f"无法连接到MySQL: {e}")
    except ValueError as ve:
        logging.error(str(ve))
    finally:
        # 如果连接到MySQL，则关闭连接
        if 'connection' in locals() and connection.is_connected():
            connection.close()
            logging.info("MySQL连接已关闭。")

if __name__ == '__main__':
    try:
        main()
    except Exception as e:
        logging.critical(f"应用程序发生严重错误: {e}")
