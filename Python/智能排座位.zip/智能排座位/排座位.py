class SmartSeatingSystem:
    def __init__(self, num_rows, num_cols):
        self.num_rows = num_rows
        self.num_cols = num_cols
        self.seats = [[None for _ in range(num_cols)] for _ in range(num_rows)]
        self.students = []
        self.student_preferences = {}
        self.area_restrictions = {}
        self.seat_limits = {}
        self.student_distances = {}

    def add_student(self, name, preferences=None):
        student = {'name': name, 'preferences': preferences}
        self.students.append(student)
        if preferences:
            self.student_preferences[name] = preferences

    def add_area_restriction(self, area_name, restriction):
        self.area_restrictions[area_name] = restriction

    def add_seat_limit(self, area_name, limit):
        self.seat_limits[area_name] = limit

    def add_student_distance(self, student1, student2, distance):
        # 添加两个学生的距离信息
        self.student_distances[(student1, student2)] = distance

    def allocate_seats(self):
        for student in self.students:
            allocated_seat = self.allocate_seat(student['name'], student['preferences'])
            if allocated_seat:
                print(f"{student['name']} 被分配到了 {allocated_seat}")
            else:
                print(f"{student['name']} 没有找到合适的座位")

    def allocate_seat(self, student_name, preference):
        # 这里可以添加更多的分配策略
        if preference == 'random':
            return self._allocate_random_seat(student_name)
        elif preference == 'closest_to_front':
            return self._allocate_closest_to_front_seat(student_name)
        else:
            raise ValueError("无效的座位分配偏好")

    def _allocate_random_seat(self, student_name):
        import random
        available_rows = [row for row in range(self.num_rows) if all(self.seats[row])]
        if not available_rows:
            return None
        row = random.choice(available_rows)
        col = random.choice([col for col in range(self.num_cols) if self.seats[row][col] is None])
        self.seats[row][col] = student_name
        return (row + 1, col + 1)

    def _allocate_closest_to_front_seat(self, student_name):
        # 根据实际情况实现最靠前排的座位分配逻辑
        pass

    def free_seat(self, row, col):
        if row < 1 or row > self.num_rows or col < 1 or col > self.num_cols:
            raise ValueError("无效的座位坐标")
        self.seats[row - 1][col - 1] = None

    def print_seating_chart(self):
        for row in range(self.num_rows):
            print(f"第{row + 1}排: {' '.join(['O' if self.seats[row][col] is not None else 'X' for col in range(self.num_cols)])}")

# 使用示例
system = SmartSeatingSystem(4, 5)
students_df = pd.DataFrame(columns=['编号', '姓名', '偏好'])
students_df = students_df.append({'编号': '001', '姓名': '爱丽丝', '偏好': {'行偏好': 2}}, ignore_index=True)
students_df = students_df.append({'编号': '002', '姓名': '鲍勃', '偏好': {'行偏好': 2}}, ignore_index=True)
students_df = students_df.append({'编号': '003', '姓名': '查理', '偏好': {'行偏好': 3}}, ignore_index=True)
for index, row in students_df.iterrows():
    system.add_student(row['姓名'], preferences=row['偏好'])
system.add_area_restriction('前排', {'rows': [1], 'cols': [1, 2, 3, 4, 5]})
system.add_seat_limit('前排', 2)
system.add_student_distance('爱丽丝', '鲍勃', 1)
system.add_student_distance('鲍勃', '查理', 1)
system.add_student_distance('查理', '爱丽丝', 1)
system.allocate_seats()
system.print_seating_chart()
